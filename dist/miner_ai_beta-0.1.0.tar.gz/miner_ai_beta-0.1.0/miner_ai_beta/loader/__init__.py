from .docs import IndexFromDocs
from .excels import IndexFromXlss
from .web_pages import IndexFromWebPages
from .pdfs import IndexFromPdfs
from .tubes import IndexFromTubes
from .ppts import IndexFromPpts
from .union import MergeIndexes